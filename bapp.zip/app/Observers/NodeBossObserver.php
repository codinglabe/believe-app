<?php

namespace App\Observers;

class NodeBossObserver
{
    //
}
